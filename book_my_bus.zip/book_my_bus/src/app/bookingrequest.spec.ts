import { Bookingrequest } from './bookingrequest';

describe('Bookingrequest', () => {
  it('should create an instance', () => {
    expect(new Bookingrequest()).toBeTruthy();
  });
});
