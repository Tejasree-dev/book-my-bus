export interface Booking {
    id?: number; // Optional for new bookings
    busId: number; // Assuming the flight is selected by ID
    numberOfSeats: number;
    adultusers: number;
    childusers: number;
    infantusers: number;
    bookingDate: string; // Use ISO date string format
  }  
