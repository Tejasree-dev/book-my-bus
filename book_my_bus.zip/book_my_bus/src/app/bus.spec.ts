import { Bus } from './bus';

describe('Flight', () => {
  it('should create an instance', () => {
    expect(new Bus()).toBeTruthy();
  });
});
