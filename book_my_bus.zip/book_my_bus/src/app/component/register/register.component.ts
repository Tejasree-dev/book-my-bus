import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { RegistrationServiceService } from '../../service/registration-service.service';
import { CommonModule, formatDate } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  registrationForm: FormGroup;
  message: string = '';
  errorMessage: string = '';
  constructor(
    private fb: FormBuilder, 
    private registrationService: RegistrationServiceService,
    private router: Router  // Inject Router for redirection
  ) {
    // Initialize the form with validation
    this.registrationForm = this.fb.group({
      title: ['', Validators.required],
      firstName: ['', [Validators.required, Validators.minLength(2)]],
      lastName: ['', [Validators.required, Validators.minLength(2)]],
      dateOfBirth: ['', Validators.required],
      phoneNumber: ['', [Validators.required, Validators.pattern('^((\\+91-?)|0)?[0-9]{10}$')]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  // Handle form submission
  onSubmit() {
    if (this.registrationForm.valid) {
      console.log('Form submitted:', this.registrationForm.value);
      this.registrationService.registerUser(this.registrationForm.value).subscribe(
        (response: any) => {
          this.message = 'Registration Successful! Redirecting to login page...';
          setTimeout(() => {
            this.router.navigate(['/login']);
          }, 4000);
          this.registrationForm.reset();
        },
        (error: any) => {
          console.error('Error registering user', error);
        }
      );
    } else {
      console.log('Form is not valid');
    }
  }
  
  // Helper function to format the date
  formatDate(date: string): string {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    
    return `${year}-${month}-${day}`;
  }

}