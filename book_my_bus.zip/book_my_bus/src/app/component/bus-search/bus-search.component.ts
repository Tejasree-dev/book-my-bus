import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Bus } from '../../bus';
import { BusService } from '../../service/bus.service';

@Component({
  selector: 'app-bus-search',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './bus-search.component.html',
  styleUrl: './bus-search.component.css'
})
export class BusSearchComponent  {
  source: string = '';
  destination: string = '';
  departureDate: string = '';
  returnDate?: string = '';
  flights: Bus[] = [];
  message: string = '';
  buses: Array<any> = []; // Define buses as an array

  constructor(private busService: BusService) {}
  
  searchBuses() {
    this.busService.searchBus(this.source, this.destination, this.departureDate, this.returnDate ).subscribe(
      (data) => {
        this.buses = data;
        if (this.buses.length === 0) {
          this.message = 'No Buses found.';
        } else {
          this.message = '';
        }
      },
      (error) => {
        this.message = 'Error fetching Buses.';
      }
    );
  }
}

    
  

