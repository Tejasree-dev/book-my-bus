import { Component } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { BookingResponse } from '../../bookingresponse';
import { BookingRequest } from '../../bookingrequest';
import { CommonModule } from '@angular/common'
import { response } from 'express';
import { BookingServiceService } from '../../service/reservation.service';

@Component({
  selector: 'app-bookingseat',
  standalone: true,
  imports: [FormsModule,CommonModule,ReactiveFormsModule],
  templateUrl: './bookingseat.component.html',
  styleUrl: './bookingseat.component.css'
})
export class BookingseatComponent {

  bookingForm: FormGroup;
  bookingResponse: BookingResponse | null = null;
  errorMessage: string | null = null;
 message:string | null=null;
  constructor(private bookingService: BookingServiceService, private fb: FormBuilder) {
    this.bookingForm = this.fb.group({
      busId: [null, Validators.required],
      users: this.fb.array([this.createuser()])
    });
  }

  createuser(): FormGroup {
    return this.fb.group({
      seatNumber: ['', Validators.required],
      userName: ['', Validators.required],
      userEmail: ['', [Validators.required, Validators.email]],
      userPhoneNumber: ['', Validators.required]
    });
  }

  get users(): FormArray {
    return this.bookingForm.get('users') as FormArray;
  }

  adduser() {
    this.users.push(this.createuser());
  }

  removeuser(index: number) {
    this.users.removeAt(index);
  }


  onSubmit() {
    if (this.bookingForm.valid) {
      const busId = this.bookingForm.value.busId;
      const bookingRequests: BookingRequest[] = this.bookingForm.value.users.map((user: any) => ({
        seatNumber: user.seatNumber,
        userName: user.userName,
        userEmail: user.userEmail,
        userPhoneNumber: user.userPhoneNumber,
      }));

      this.bookingService.bookSeats(busId, bookingRequests).subscribe(
        response=> {
          this.bookingResponse = response;
          this.message="Continue To payment"
          this.errorMessage = null;
        },
        error => {
          this.errorMessage = error;
          this.bookingResponse = null;
        }
      );
    }
  }
}