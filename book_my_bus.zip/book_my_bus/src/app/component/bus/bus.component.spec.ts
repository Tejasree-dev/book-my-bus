import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Buscomponent } from './bus.component';



describe('BusComponent', () => {
  let component: Buscomponent;
  let fixture: ComponentFixture<Buscomponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Buscomponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Buscomponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
