import { Component, OnInit } from '@angular/core';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { User } from '../../user';
import { BusService } from '../../service/bus.service';

@Component({
  selector: 'app-bus',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './bus.component.html',
  styleUrl: './bus.component.css'
})
export class Buscomponent implements OnInit {
  users: User[] = [];
  selectedSeatId: number | null = null;
  errorMessage: string | null = null;

  constructor(private busService: BusService) {}

  ngOnInit(): void {
    this.getAllUsers();
  }

  getAllUsers(): void {
    this.busService.getAllUsers().subscribe(
      (data: User[]) => {
        this.users = data;
      },
      (error: string) => {
        this.errorMessage = error;
      }
    );
  }

  getUsersBySeatId(): void {
    if (this.selectedSeatId) {
      this.busService.getUsersBySeatId(this.selectedSeatId).subscribe(
        (data: User[]) => {
          this.users = data;
        },
        (error: string) => {
          this.errorMessage = error;
        }
      );
    }
  }
}
