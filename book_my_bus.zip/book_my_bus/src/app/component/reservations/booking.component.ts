import { Component } from '@angular/core';
import { Booking } from '../../booking';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BookingServiceService } from '../../service/reservation.service';

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule,FormsModule],
  templateUrl: './booking.component.html',
  styleUrl: './booking.component.css'
})
export class BookingComponent {
  booking: Booking = {
    busId: 0,
    numberOfSeats: 0,
    adultusers: 0,
    childusers: 0,
    infantusers: 0,
    bookingDate: new Date().toISOString() // Default to now
  };
  bookingId: number | null = null;
  message: string = '';
  

  constructor(private bookingService: BookingServiceService) { }

  createBooking() {
    this.bookingService.createBooking(this.booking).subscribe()
      
        this.message = 'Continue to select seat';// Success message
      
      
        (error: any) => {
          this.message = 'Error Booking';
          
        }
    
  }

  

  deleteBooking() {
    if (this.bookingId) {
      this.bookingService.deleteBooking(this.bookingId).subscribe()
       
        this.message = 'Booking Stopped successfully!';
          this.bookingId = null; // Reset bookingId
        // Clear retrieved booking
        (error: any) => {
          this.message = ' Booking Not stopped';
          
        }
    }
  }
}
