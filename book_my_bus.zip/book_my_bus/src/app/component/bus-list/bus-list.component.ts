import { Component } from '@angular/core';

@Component({
  selector: 'app-bus-list',
  standalone: true,
  imports: [],
  templateUrl: './bus-list.component.html',
  styleUrl: './bus-list.component.css'
})
export class BusListComponent {


}
