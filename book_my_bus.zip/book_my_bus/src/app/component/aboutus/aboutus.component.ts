
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';




@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css']
})
export class AboutusComponent implements OnInit {

  title = 'About Us';
  description = 'ocean-Airlines is a leading airline company that provides safe, reliable, and comfortable air travel to our customers.';
  mission = 'Our mission is to provide exceptional customer service while maintaining the highest standards of safety and quality.';
  vision = 'Our vision is to be the airline of choice for our customers and to be a leader in the aviation industry.';
  values = [
    'Safety: We prioritize the safety of our customers and employees above all else.',
    'Customer Service: We strive to provide exceptional customer service, every time, every flight.',
    'Quality: We maintain the highest standards of quality in everything we do.',
    'Innovation: We continuously look for ways to improve and innovate our services and operations.',
    'Teamwork: We work together as a team to achieve our goals and provide the best possible experience for our customers.'
  ];

  email = 'contact@oceanairlines.com';
  phone = '+1-800-123-4567';

  contactForm: FormGroup | null = null;
  successMessage = '';

  constructor(private fb: FormBuilder) { }

  ngOnInit(): void {
    this.contactForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      message: ['', Validators.required]
    });
  }

  onSubmit(): void {
    if (this.contactForm?.valid) {
      console.log('Form Submitted', this.contactForm.value);
      // Handle form submission, e.g., send the data to a server
      this.successMessage = 'Message sent successfully! Our team will contact you soon.';
    } else {
      console.log('Form is invalid');
    }
  }
}