
import { Component } from '@angular/core';
import { FormBuilder,FormGroup,ReactiveFormsModule,Validators } from '@angular/forms';
import { LoginServiceService } from '../../service/login-service.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent {

  forgotPasswordForm: FormGroup;
  resetPasswordForm: FormGroup;
  tokenGenerated: boolean = false;
  resetToken: string = '';

  constructor(private fb: FormBuilder, private loginService: LoginServiceService) {
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
    });

    this.resetPasswordForm = this.fb.group({
      token: ['', Validators.required],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  /*
  // Handle Forgot Password form submission
  onForgotPasswordSubmit() {
    if (this.forgotPasswordForm.valid) {
      const email = this.forgotPasswordForm.get('email')?.value;
      this.loginService.forgotPassword( email ).subscribe(
        (response: any) => {
          console.log('Forgot Password Success:', response);
          this.tokenGenerated = true;
          this.resetToken = response.token;  // Assuming the token is returned in the response
          alert(`Password reset token: ${this.resetToken}`); // Display the token in an alert
        },
        (error: any) => {
          console.error('Forgot Password Error:', error);
        }
      );
    }
  }

   // Handle Reset Password form submission
   onResetPasswordSubmit() {
    if (this.resetPasswordForm.valid) {
      const token = this.resetPasswordForm.get('token')?.value;
      const newPassword = this.resetPasswordForm.get('newPassword')?.value;

      this.loginService.resetPassword(token, newPassword).subscribe( // Pass token and newPassword separately
        (response: any) => {
          console.log('Password Reset Success:', response);
          alert('Password updated successfully!');
          // Redirect to login page after successful password update
        },
        (error: any) => {
          console.error('Password Reset Error:', error);
        }
      );
    }
  }
  
  */
  // Handle Forgot Password form submission
  onForgotPasswordSubmit() {
    if (this.forgotPasswordForm.valid) {
      const email = this.forgotPasswordForm.get('email')?.value;
      this.loginService.forgotPassword(email).subscribe(
        (response: any) => {
          console.log('Forgot Password Success:', response);

          // Ensure response contains the reset token
          if (response.token) {
            this.tokenGenerated = true;
            this.resetToken = response.token;  // Correctly assign the token
            alert(`Password reset token: ${this.resetToken}`); // Show pop-up with token
          } else {
            alert('No token received. Please try again.');
          }
        },
        (error: any) => {
          console.error('Forgot Password Error:', error);
        }
      );
    }
  }

  // Handle Reset Password form submission
  onResetPasswordSubmit() {
    if (this.resetPasswordForm.valid) {
      const token = this.resetPasswordForm.get('token')?.value;
      const newPassword = this.resetPasswordForm.get('newPassword')?.value;

      this.loginService.resetPassword(token, newPassword).subscribe(
        (response: any) => {
          console.log('Password Reset Success:', response);
          alert('Password updated successfully!');
        },
        (error: any) => {
          console.error('Password Reset Error:', error);
        }
      );
    }
  }




}
