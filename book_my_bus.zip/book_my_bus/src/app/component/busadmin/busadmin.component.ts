import { Component, OnInit } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Bus } from '../../bus';
import { BusService } from '../../service/bus.service';


@Component({
  selector: 'app-flightadmin',
  standalone: true,
  imports: [CommonModule,FormsModule,ReactiveFormsModule],
  templateUrl: './flightadmin.component.html',
  styleUrl: './flightadmin.component.css'
})
export class FlightAdminComponent implements OnInit {
  flights: Bus[] = [];
  newFlight: Bus = {
    id:'' ,
    busNumber: '',
    source: '',
    destination: '',
    departureDate: '',
    returnDate: '',
    availableSeats: 0,
    fare: 0,
    busClass: ''
  
  };
  flight: Bus[] = [];
  showFlightList: boolean = false;

  constructor(private flightService: BusService,
    private router:Router
  ) {}

  ngOnInit(): void {
    this.loadFlights();
  }

  loadFlights(): void {
    this.flightService.viewBus().subscribe(buses => {
      this.flights = buses;
    });
  }

  addFlight(): void {
    this.flightService.addBus(this.newFlight).subscribe(() => {
      this.loadFlights();
      this.newFlight = {
        id:'',
        busNumber: '',
        source: '',
        destination: '',
        departureDate: '',
        returnDate: '',
        availableSeats: 0,
        fare: 0,
        busClass: ''
      }; // Reset form
    });
  }

  deleteFlight(id: number): void {
    this.flightService.deleteBus(id).subscribe(() => {
      this.loadFlights();
    });
  }
  viewBuses() {
    this.router.navigate(['/bus-list']);
  }

  toggleBusList() {
    this.showBusList = !this.showBusList;
  }
  // Cancel method to redirect to login page
  cancel() {
    this.router.navigate(['/login']); // Adjust the path as needed
  }
}


