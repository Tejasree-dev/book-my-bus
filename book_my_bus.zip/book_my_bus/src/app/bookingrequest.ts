export interface BookingRequest {
    seatNumber: string;
    passengerName: string;
    passengerEmail: string;
    passengerPhoneNumber: string;
}
