import { Bookingresponse } from './bookingresponse';

describe('Bookingresponse', () => {
  it('should create an instance', () => {
    expect(new Bookingresponse()).toBeTruthy();
  });
});
