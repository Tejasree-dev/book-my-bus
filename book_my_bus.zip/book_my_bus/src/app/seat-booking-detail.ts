export interface SeatBookingDetail {
    seatNumber: string;
    user: any; // Adjust this type based on your Passenger model
    bookingStatus: string;
  }
