export interface User {
    id: number;
    name: string;
    email: string;
    phoneNumber:number;
    seatId: number;
  }