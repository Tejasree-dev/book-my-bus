import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { catchError, Observable, throwError } from 'rxjs';
import { Bus } from '../bus';
import { User } from '../user';

// Import your bus model

@Injectable({
  providedIn: 'root'
})
export class BusService {
  private baseUrl: string = 'http://localhost:8080/api/bus';

  constructor(private http: HttpClient) {}

  addBus(bus: Bus): Observable<Bus> {
    return this.http.post<Bus>(`${this.baseUrl}/add`, bus);
  }

  deleteBus(id: number): Observable<string> {
    return this.http.delete<string>(`${this.baseUrl}/delete/${id}`);
  }

  viewBus(): Observable<Bus[]> {
    return this.http.get<Bus[]>(`${this.baseUrl}/view`);
  }

  private apiUrl1 = 'http://localhost:8080/api/buses/search';

  searchBus(source: string, destination: string, departureDate: string, returnDate?: string): Observable<Bus[]> {
    let params = new HttpParams()
      .set('source', source)
      .set('destination', destination)
      .set('departureDate', departureDate);

    if (returnDate) {
      params = params.set('returnDate', returnDate);
    }

    return this.http.get<Bus[]>(`${this.apiUrl1}/search`, { params });
  }


  searchBusByWay(source: string, destination: string): Observable<Bus[]> {
    const params = new HttpParams()
      .set('source', source)
      .set('destination', destination);

    return this.http.get<Bus[]>(`${this.apiUrl1}/search/sd`, { params });
  }

  searchBusByDate(departureDate: string, returnDate: string): Observable<Bus[]> {
    const params = new HttpParams()
      .set('departureDate', departureDate)
      .set('returnDate', returnDate);

    return this.http.get<Bus[]>(`${this.apiUrl1}/search/t`, { params });
  }

   // Get all users
   getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}/details`)
      .pipe(catchError(this.handleError));
  }

  // Get users by seat ID
  getUsersBySeatId(seatId: number): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}/Users/${seatId}`)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'An unknown error occurred!';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}

