import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Booking } from '../booking';
import { catchError, Observable, throwError } from 'rxjs';
import { BookingRequest } from '../bookingrequest';
import { BookingResponse } from '../bookingresponse';

@Injectable({
  providedIn: 'root'
})
export class BookingServiceService {

  private apiUrl = 'http://localhost:8080/api/reservations'; // Update with your API URL

  constructor(private http: HttpClient) { }

  createBooking(booking: Booking): Observable<string> {
    return this.http.post<string>(this.apiUrl, booking);
  }

  getBooking(id: number): Observable<Booking> {
    return this.http.get<Booking>(`${this.apiUrl}/${id}`);
  }

  deleteBooking(id: number): Observable<string> {
    return this.http.delete<string>(`${this.apiUrl}/delete/${id}`);
  }

  private apiUrl1 = 'http://localhost:8080/api/buses'

  bookSeats(busId: number, bookingRequests: BookingRequest[]): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${this.apiUrl1}/${busId}/book`, bookingRequests)
      .pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    return throwError('An error occurred: ' + (error.error.message || error.message));
  }
}
