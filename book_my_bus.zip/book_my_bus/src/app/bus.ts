export interface Bus {
    id?: number | any;
    busNumber: string;
    source?: string;
    destination?: string;
    departureDate?: string; // Use ISO date string format
    returnDate ?: string; // Use ISO date string format
    availableSeats: number;
    fare: number;
    busClass: string;
  }
  
