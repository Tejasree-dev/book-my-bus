import { Routes } from '@angular/router';
import { HomeComponent } from './component/home/home.component';

import { RegisterComponent } from './component/register/register.component';
import { LoginComponent } from './component/login/login.component';
import { ForgotPasswordComponent } from './component/forgot-password/forgot-password.component';
import { BookingComponent } from './component/reservations/booking.component';
import { SeatComponent } from './component/seat/seat.component';
import { BookingseatComponent } from './component/bookingseat/bookingseat.component';
import { PaymentComponent } from './component/payment/payment.component';
import { AboutusComponent } from './component/aboutus/aboutus.component';
import { LogoutComponent } from './component/logout/logout.component';
import { BusSearchComponent } from './component/bus-search/bus-search.component';
import { Buscomponent } from './component/bus/bus.component';




export const routes: Routes = [
    {path:'',redirectTo:'home',pathMatch:'full'},
    {path:'home', component:HomeComponent},
    {path:'register',component: RegisterComponent},
    {path:'login',component: LoginComponent},
    { path: 'forgot-password', component: ForgotPasswordComponent },  // Add this route
    { path: 'buses', component: BusSearchComponent },
    { path: 'search', component: BusSearchComponent },
    {path:'aboutus',component:AboutusComponent} ,
    { path: '', redirectTo: '/bookings', pathMatch: 'full' }, // Redirect to bookings on startup
    { path: 'bookings', component: BookingComponent }, // Route for the Booking component
    // Add more routes here as needed
    {path:'bus',component:Buscomponent},
    

    { path: 'add-seats', component:SeatComponent},
  // Route for seat selection if applicable
  { path: 'book', component: BookingseatComponent },
  {path: 'payment',component: PaymentComponent},
  {path:'logout',component:LogoutComponent},
];

