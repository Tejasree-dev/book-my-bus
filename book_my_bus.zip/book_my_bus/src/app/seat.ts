export interface Seat {
  id?: number;
  seatNumber: string;
  isAvailable: boolean;
  
}
