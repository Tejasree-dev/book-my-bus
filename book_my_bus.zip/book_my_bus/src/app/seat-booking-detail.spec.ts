import { SeatBookingDetail } from './seat-booking-detail';

describe('SeatBookingDetail', () => {
  it('should create an instance', () => {
    expect(new SeatBookingDetail()).toBeTruthy();
  });
});
