package com.wipro.training.busbooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyBusApplicationTests {

	@Test
	void contextLoads() {
	}

}
