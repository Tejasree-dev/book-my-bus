package com.wipro.training.busbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.busbooking.model.Route;
import com.wipro.training.busbooking.service.RouteService;

@RestController
@RequestMapping("/admin/route")
public class RouteController {

    @Autowired
    private RouteService routeService;

    @PostMapping("/add")
    public ResponseEntity<?> addRoute(@RequestBody Route route) {
        routeService.addRoute(route);
        return ResponseEntity.ok("Route added successfully");
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<?> removeRoute(@PathVariable Long id) {
        routeService.removeRoute(id);
        return ResponseEntity.ok("Route removed successfully");
    }
}