package com.wipro.training.busbooking.service;

import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.training.busbooking.model.Reservation;
import com.wipro.training.busbooking.repositroy.ReservationRepository;

@Service
public class TicketService {

    @Autowired
    private ReservationRepository reservationRepository;

    public String generateTicket(Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        // Format the reservation details into a ticket string
        StringBuilder ticket = new StringBuilder();
        ticket.append("--------- Bus Ticket ---------\n");
        ticket.append("Reservation ID: ").append(reservation.getId()).append("\n");
        ticket.append("Name: ").append(reservation.getUser().getFirstName())
                .append(" ").append(reservation.getUser().getLastName()).append("\n");
        ticket.append("Email: ").append(reservation.getUser().getEmail()).append("\n");
        ticket.append("Bus Number: ").append(reservation.getBus().getBusNumber()).append("\n");
        ticket.append("Source: ").append(reservation.getBus().getSource()).append("\n");
        ticket.append("Destination: ").append(reservation.getBus().getDestination()).append("\n");
        ticket.append("Seat Number: ").append(reservation.getSeatNumber()).append("\n");
        ticket.append("Fare: ").append(reservation.getBus().getFare()).append("\n");

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        String travelDate = dateFormat.format(reservation.getBus().getTravelDate());
        ticket.append("Travel Date: ").append(travelDate).append("\n");
        ticket.append("Reservation Date: ").append(dateFormat.format(reservation.getReservationDate())).append("\n");
        ticket.append("-----------------------------\n");

        return ticket.toString();
    }
}
