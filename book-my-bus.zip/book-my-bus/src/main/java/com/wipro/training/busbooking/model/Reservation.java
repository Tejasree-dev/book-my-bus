package com.wipro.training.busbooking.model;





import java.util.Date;

import jakarta.persistence.*;

@Entity
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User user;

    @ManyToOne
    private Bus bus;

    private String seatNumber;
    private Date reservationDate;
    private boolean canceled;
    private double totalFare;
    
    @Column(name = "profit")
    private double profit; 
    
    public Reservation() {
        
    }

    public Reservation(Long id, User user, Bus bus, String seatNumber, Date reservationDate, boolean canceled,
            double totalFare, double profit) {
        super();
        this.id = id;
        this.user = user;
        this.bus = bus;
        this.seatNumber = seatNumber;
        this.reservationDate = reservationDate;
        this.canceled = canceled;
        this.totalFare = totalFare;
        this.profit = profit;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Bus getBus() {
        return bus;
    }

    public void setBus(Bus bus) {
        this.bus = bus;
    }

    public String getSeatNumber() {
        return seatNumber;
    }

    public void setSeatNumber(String seatNumber) {
        this.seatNumber = seatNumber;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date date) {
        this.reservationDate = date;
    }

    public boolean isCanceled() {
        return canceled;
    }

    public void setCanceled(boolean canceled) {
        this.canceled = canceled;
    }

    public double getTotalFare() {
        return totalFare;
    }

    public void setTotalFare(double totalFare) {
        this.totalFare = totalFare;
    }

    public double getProfit() {
        return profit;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }

}