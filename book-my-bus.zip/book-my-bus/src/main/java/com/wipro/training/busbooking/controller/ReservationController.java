package com.wipro.training.busbooking.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.wipro.training.busbooking.model.Reservation;
import com.wipro.training.busbooking.model.User;
import com.wipro.training.busbooking.service.ReservationService;
import com.wipro.training.busbooking.service.UserService;

@RestController
@RequestMapping("/api/reservations")
public class ReservationController {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private UserService userService;

    // Add a reservation
    @PostMapping("/add")
    public ResponseEntity<Reservation> addReservation(@RequestBody Reservation reservation) {
        try {
            Reservation savedReservation = reservationService.saveReservation(reservation);
            return new ResponseEntity<>(savedReservation, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
        }
    }

    // Get all reservations
    @GetMapping("/all")
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> reservations = reservationService.getAllReservations();
        if (reservations.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(reservations, HttpStatus.OK);
    }

    // Reserve a seat
    @PostMapping("/reserve")
    public ResponseEntity<?> reserveSeat(@RequestParam String email, 
                                          @RequestParam Long busId, 
                                          @RequestParam String seatNumber) {
        Optional<User> optionalUser = userService.findUserByEmail(email);
        if (!optionalUser.isPresent()) {
            return new ResponseEntity<>("User not found", HttpStatus.NOT_FOUND);
        }
        User user = optionalUser.get();
        try {
            Reservation reservation = reservationService.reserveSeat(user, busId, seatNumber);
            return new ResponseEntity<>(reservation, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }

    // Cancel reservation by email
    @PostMapping("/cancel/{email}")
    public ResponseEntity<?> cancelReservation(@PathVariable(value="email") String email) {
        try {
            boolean canceled = reservationService.cancelReservationByEmail(email);
            if (canceled) {
                return new ResponseEntity<>("Reservations canceled successfully", HttpStatus.OK);
            } else {
                return new ResponseEntity<>("No reservations were canceled", HttpStatus.OK);
            }
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}
