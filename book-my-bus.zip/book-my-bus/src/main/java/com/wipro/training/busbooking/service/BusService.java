package com.wipro.training.busbooking.service;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.training.busbooking.model.Bus;
import com.wipro.training.busbooking.repositroy.BusRepository;

@Service
public class BusService {

    @Autowired
    private BusRepository busRepository;

    // Method to search for buses based on source and destination
    public List<Bus> findBuses(String source, String destination) {
        return busRepository.findBySourceAndDestination(source, destination);
    }

    // Method to update bus details
    public Bus updateBus(Long busId, Bus busDetails) {
        Bus bus = busRepository.findById(busId).orElseThrow(() -> new RuntimeException("Bus not found"));
        bus.setSource(busDetails.getSource());
        bus.setDestination(busDetails.getDestination());
        bus.setAvailableSeats(busDetails.getAvailableSeats());
        // Set other bus details as needed
        return busRepository.save(bus);
    }

    // Method to retrieve a bus by ID
    public Bus getBusById(Long busId) {
        return busRepository.findById(busId).orElseThrow(() -> new RuntimeException("Bus not found"));
    }

	

	public List<Bus> checkBusAvailability(String departureLocation, String destination, LocalDate travelDate) {
        return busRepository.findBySourceAndDestinationAndTravelDate(departureLocation, destination, travelDate);

	}

	public Bus saveBus(Bus bus) {
		return busRepository.save(bus);
	}

	public List<Bus> getAllBuses() {
		return busRepository.findAll();
	}

	 public String removeBus(Long busId) {
	        // Check if the bus exists in the repository
	        if(busRepository.existsById(busId)) {
	            // Remove the bus
	            busRepository.deleteById(busId);
	            return "Bus removed successfully";
	        } else {
	            // If the bus doesn't exist, return a message
	            return "Bus with ID " + busId + " not found";
	        }
	    }
}
