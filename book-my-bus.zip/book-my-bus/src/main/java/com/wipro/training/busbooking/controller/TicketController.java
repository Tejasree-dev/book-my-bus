package com.wipro.training.busbooking.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.busbooking.model.Reservation;
import com.wipro.training.busbooking.service.ReservationService;
import com.wipro.training.busbooking.service.TicketPrinter;

@RestController
@RequestMapping("/api/ticket")
public class TicketController {

    @Autowired
    private ReservationService reservationService;  // Inject ReservationService

    @Autowired
    private TicketPrinter ticketPrinter;  // Inject TicketPrinter

    @GetMapping("/print")
    public ResponseEntity<?> printTicket(@RequestParam Long reservationId) {
        try {
            // Fetch reservation by ID
            Reservation reservation = reservationService.findReservationById(reservationId);

            // Generate ticket
            String ticket = ticketPrinter.printTicket(reservation);

            // Return ticket as a response
            return new ResponseEntity<>(ticket, HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        }
    }
}
