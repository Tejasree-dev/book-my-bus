package com.wipro.training.busbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.wipro.training.busbooking.model.Wallet;
import com.wipro.training.busbooking.service.UserService;
import com.wipro.training.busbooking.service.WalletService;

@RestController
@RequestMapping("/api/wallet")
public class WalletController {

    @Autowired
    private WalletService walletService;

    @Autowired
    private UserService userService;

    @PostMapping("/create")
    public ResponseEntity<String> createWallet(@RequestBody Wallet wallet) {
        try {
            // Validate user
            if (wallet.getUser() == null || wallet.getUser().getId() == null) {
                return new ResponseEntity<>("User ID is required", HttpStatus.BAD_REQUEST);
            }

            // Validate wallet balance
            if (wallet.getBalance() < 0) {
                return new ResponseEntity<>("Balance cannot be negative", HttpStatus.BAD_REQUEST);
            }

            // Create or update the wallet
            walletService.createOrUpdateWallet(wallet);
            return new ResponseEntity<>("Wallet created/updated successfully", HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}