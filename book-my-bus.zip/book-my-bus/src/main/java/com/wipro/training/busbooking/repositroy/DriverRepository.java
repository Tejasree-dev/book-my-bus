package com.wipro.training.busbooking.repositroy;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.training.busbooking.model.Driver;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {
    // JpaRepository provides all the basic CRUD operations (save, findById, delete, etc.)
}