package com.wipro.training.busbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.training.busbooking.model.Driver;
import com.wipro.training.busbooking.repositroy.DriverRepository;

@Service
public class DriverService {

    @Autowired
    private DriverRepository driverRepository;

    // Add a new driver
    public Driver addDriver(Driver driver) {
        return driverRepository.save(driver);
    }

    // Update an existing driver
    public Driver updateDriver(Long driverId, Driver updatedDriver) {
        return driverRepository.findById(driverId).map(driver -> {
            driver.setName(updatedDriver.getName());
            driver.setLicenseNumber(updatedDriver.getLicenseNumber());
            driver.setContactNumber(updatedDriver.getContactNumber());
            return driverRepository.save(driver);
        }).orElseThrow(() -> new RuntimeException("Driver not found with ID: " + driverId));
    }

    // Remove a driver
    public String removeDriver(Long driverId) {
        if (driverRepository.existsById(driverId)) {
            driverRepository.deleteById(driverId);
            return "Driver removed successfully";
        } else {
            return "Driver with ID " + driverId + " not found";
        }
    }

    // Get all drivers
    public List<Driver> getAllDrivers() {
        return driverRepository.findAll();
    }

    // Get a specific driver by ID
    public Driver getDriverById(Long driverId) {
        return driverRepository.findById(driverId)
            .orElseThrow(() -> new RuntimeException("Driver not found with ID: " + driverId));
    }
}
