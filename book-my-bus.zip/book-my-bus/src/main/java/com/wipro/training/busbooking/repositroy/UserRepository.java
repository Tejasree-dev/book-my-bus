package com.wipro.training.busbooking.repositroy;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.wipro.training.busbooking.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    
    // Custom query to find users who have not made any reservations
    @Query("SELECT u FROM User u WHERE u.id NOT IN (SELECT r.user.id FROM Reservation r)")
    List<User> findCustomersWithoutReservations();
}
