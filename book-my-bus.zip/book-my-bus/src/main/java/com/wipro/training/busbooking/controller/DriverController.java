package com.wipro.training.busbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.busbooking.model.Driver;
import com.wipro.training.busbooking.service.DriverService;

@RestController
@RequestMapping("/admin/driver")
public class DriverController {

    @Autowired
    private DriverService driverService;

    @PostMapping("/add")
    public ResponseEntity<?> addDriver(@RequestBody Driver driver) {
        driverService.addDriver(driver);  // Call the instance method from the injected service
        return ResponseEntity.ok("Driver added successfully");
    }
}
