package com.wipro.training.busbooking.repositroy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.wipro.training.busbooking.model.Route;

public interface RouteRepository extends JpaRepository<Route, Long> {

    // Custom query to find frequently traveled routes by start and end points (with multiple values)
	@Query("SELECT r FROM Route r WHERE r.startPoint IN :startPoints AND r.endPoint IN :endPoints")
	List<Route> findRoutesByStartAndEndPoints(@Param("startPoints") List<String> startPoints, @Param("endPoints") List<String> endPoints);

    // Custom query to find routes by start points only
    @Query("SELECT r FROM Route r WHERE r.startPoint IN :startPoints")
    List<Route> findRoutesByStartPoints(@Param("startPoints") List<String> startPoints);

    // Custom query to find frequently traveled routes
    @Query("SELECT r FROM Reservation res JOIN res.bus b JOIN b.route r GROUP BY r ORDER BY COUNT(res) DESC")
    List<Route> findFrequentlyTraveledRoutes();
}

