package com.wipro.training.busbooking.repositroy;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.wipro.training.busbooking.model.Bus;

public interface BusRepository extends JpaRepository<Bus, Long> {
	
    List<Bus> findBySourceAndDestinationAndTravelDate(String source, String destination, LocalDate travelDate);

	List<Bus> findBySourceAndDestination(String source, String destination);
}
