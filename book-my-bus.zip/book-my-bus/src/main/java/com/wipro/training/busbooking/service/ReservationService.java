package com.wipro.training.busbooking.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.training.busbooking.model.Bus;
import com.wipro.training.busbooking.model.Reservation;
import com.wipro.training.busbooking.model.User;
import com.wipro.training.busbooking.repositroy.BusRepository;
import com.wipro.training.busbooking.repositroy.ReservationRepository;
import com.wipro.training.busbooking.repositroy.UserRepository;
import com.wipro.training.busbooking.exception.ReservationNotFoundException;
import com.wipro.training.busbooking.exception.UserNotFoundException;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    @Autowired
    private BusRepository busRepository;

    @Autowired
    private UserRepository userRepository; // Inject UserRepository

    @Autowired
    private UserService userService; // Inject UserService

    // Method to reserve a seat
    public Reservation reserveSeat(User user, Long busId, String seatNumber) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new RuntimeException("Bus not found"));

        // Check if the reservation already exists for the user, bus, and seat number
        Optional<Reservation> existingReservation = reservationRepository.findByUserAndBusAndSeatNumber(user, bus, seatNumber);
        if (existingReservation.isPresent()) {
            throw new RuntimeException("Reservation already exists for this user, bus, and seat number.");
        }

        // Proceed with creating the reservation if it doesn't exist
        bus.setAvailableSeats(bus.getAvailableSeats() - 1);

        Reservation reservation = new Reservation();
        reservation.setUser(user);
        reservation.setBus(bus);
        reservation.setSeatNumber(seatNumber);
        reservation.setReservationDate(new Date());
        reservation.setCanceled(false);
        reservation.setTotalFare(bus.getFare()); // Set total fare if needed

        return reservationRepository.save(reservation);
    }

    // Save a reservation
    public Reservation saveReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    // Get all reservations
    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

    // Cancel a reservation by user and reservation ID
    public void cancelReservation(User user, Long reservationId) {
        Reservation reservation = reservationRepository.findById(reservationId)
                .orElseThrow(() -> new RuntimeException("Reservation not found"));

        // Check if the reservation belongs to the given user
        if (!reservation.getUser().equals(user)) {
            throw new RuntimeException("This reservation does not belong to the specified user.");
        }

        reservation.setCanceled(true);
        reservationRepository.save(reservation);

        // Update the bus to free up the seat
        Bus bus = reservation.getBus();
        bus.setAvailableSeats(bus.getAvailableSeats() + 1);
        busRepository.save(bus);
    }

    // Cancel reservation by email
    public boolean cancelReservationByEmail(String email) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found"));

        List<Reservation> reservations = reservationRepository.findByUser(user);
        if (reservations.isEmpty()) {
            throw new RuntimeException("No reservations found for this user");
        }

        boolean anyCanceled = false;
        for (Reservation reservation : reservations) {
            if (!reservation.isCanceled()) {
                reservation.setCanceled(true);
                reservationRepository.save(reservation);

                // Update the bus to free up the seat
                Bus bus = reservation.getBus();
                bus.setAvailableSeats(bus.getAvailableSeats() + 1);
                busRepository.save(bus);

                anyCanceled = true;
            }
        }

        return anyCanceled;
    }

    // Find reservation by ID
    

	public Reservation findReservationById(Long reservationId) {
		 return reservationRepository.findById(reservationId)
	                .orElseThrow(() -> new ReservationNotFoundException("Reservation not found with ID: " + reservationId));
	    }
}
