package com.wipro.training.busbooking.repositroy;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.training.busbooking.model.Wallet;

@Repository
public interface WalletRepository extends JpaRepository<Wallet, Long> {

    // Ensure that this method returns Optional<Wallet>
    Optional<Wallet> findByUserId(Long userId);
}