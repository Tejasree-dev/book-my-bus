package com.wipro.training.busbooking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.training.busbooking.model.User;
import com.wipro.training.busbooking.model.Wallet;
import com.wipro.training.busbooking.repositroy.UserRepository;
import com.wipro.training.busbooking.repositroy.WalletRepository;

@Service
public class WalletService {

    @Autowired
    private WalletRepository walletRepository;

    @Autowired
    private UserRepository userRepository;

    // Retrieve wallet by userId
    public Wallet getWallet(Long userId) {
        return walletRepository.findByUserId(userId)
                .orElseThrow(() -> new RuntimeException("Wallet not found for user ID: " + userId));
    }

    // Add funds to wallet
    public Wallet addFunds(Long userId, double amount) {
        Wallet wallet = getWallet(userId);
        wallet.setBalance(wallet.getBalance() + amount);
        return walletRepository.save(wallet);
    }

    // Deduct funds from wallet
    public Wallet deductFunds(Long userId, double amount) {
        Wallet wallet = getWallet(userId);
        if (wallet.getBalance() < amount) {
            throw new RuntimeException("Insufficient balance");
        }
        wallet.setBalance(wallet.getBalance() - amount);
        return walletRepository.save(wallet);
    }

    // Process payment using wallet
    public boolean processPayment(User user, double amount) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be positive");
        }

        // Retrieve wallet for the user
        Wallet wallet = walletRepository.findByUserId(user.getId())
                .orElseThrow(() -> new RuntimeException("Wallet not found for user ID: " + user.getId()));

        // Check if there are sufficient funds
        if (wallet.getBalance() < amount) {
            return false; // Insufficient funds
        }

        // Deduct the amount from the wallet balance
        wallet.setBalance(wallet.getBalance() - amount);

        // Save the updated wallet to the repository
        walletRepository.save(wallet);

        return true; // Payment processed successfully
    }

    // Create or update a wallet
    public Wallet createOrUpdateWallet(Wallet wallet) {
        Long userId = wallet.getUser().getId();
        userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not available"));

        return walletRepository.save(wallet);
    }
}
