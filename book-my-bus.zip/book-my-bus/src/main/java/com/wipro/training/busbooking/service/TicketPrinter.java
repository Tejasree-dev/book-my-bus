package com.wipro.training.busbooking.service;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.springframework.stereotype.Service;
import com.wipro.training.busbooking.model.Reservation;

@Service
public class TicketPrinter {

    // Method to print a formatted ticket
    public String printTicket(Reservation reservation) {
        // Define the date format
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        StringBuilder ticket = new StringBuilder();
        ticket.append("--------- Bus Ticket ---------\n");
        ticket.append("Reservation ID: ").append(reservation.getId()).append("\n");
        ticket.append("Passenger Name: ").append(reservation.getUser().getFirstName()).append(" ")
              .append(reservation.getUser().getLastName()).append("\n");
        ticket.append("Email: ").append(reservation.getUser().getEmail()).append("\n");
        ticket.append("Bus Number: ").append(reservation.getBus().getBusNumber()).append("\n");
        ticket.append("Source: ").append(reservation.getBus().getSource()).append("\n");
        ticket.append("Destination: ").append(reservation.getBus().getDestination()).append("\n");
        ticket.append("Seat Number: ").append(reservation.getSeatNumber()).append("\n");
        ticket.append("Fare: ").append(reservation.getTotalFare()).append("\n");

        // Format travel date and reservation date
        String travelDateFormatted = formatLocalDate(reservation.getBus().getTravelDate());
        String reservationDateFormatted = formatLocalDate(reservation.getReservationDate());

        ticket.append("Travel Date: ").append(travelDateFormatted).append("\n");
        ticket.append("Reservation Date: ").append(reservationDateFormatted).append("\n");
        ticket.append("------------------------------\n");

        return ticket.toString();
    }

    // Method to format LocalDate
    private String formatLocalDate(LocalDate localDate) {
        if (localDate == null) {
            return "N/A";
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        return localDate.format(formatter);
    }
    
    private String formatLocalDate(Date date) {
        if (date == null) {
            return "N/A";
        }
        
        // Convert Date to LocalDate
        LocalDate localDate = date.toInstant()
                                  .atZone(ZoneId.systemDefault())
                                  .toLocalDate();
        
        // Format the LocalDate
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        return localDate.format(formatter);
    }
}
