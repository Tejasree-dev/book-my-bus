package com.wipro.training.busbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.wipro.training.busbooking.model.Route;
import com.wipro.training.busbooking.repositroy.RouteRepository;

@Service
public class RouteService {

    @Autowired
    private RouteRepository routeRepository;

    // Add a new route
    public Route addRoute(Route route) {
        return routeRepository.save(route);
    }

    // Update an existing route
    public Route updateRoute(Long routeId, Route updatedRoute) {
        return routeRepository.findById(routeId).map(route -> {
            route.setName(updatedRoute.getName());
            route.setStartPoint(updatedRoute.getStartPoint());
            route.setEndPoint(updatedRoute.getEndPoint());
            return routeRepository.save(route);
        }).orElseThrow(() -> new RuntimeException("Route not found with ID: " + routeId));
    }

    // Remove a route
    public String removeRoute(Long routeId) {
        if (routeRepository.existsById(routeId)) {
            routeRepository.deleteById(routeId);
            return "Route removed successfully";
        } else {
            return "Route with ID " + routeId + " not found";
        }
    }

    // Get all routes
    public List<Route> getAllRoutes() {
        return routeRepository.findAll();
    }

    // Get a specific route by ID
    public Route getRouteById(Long routeId) {
        return routeRepository.findById(routeId)
            .orElseThrow(() -> new RuntimeException("Route not found with ID: " + routeId));
    }



   
}
