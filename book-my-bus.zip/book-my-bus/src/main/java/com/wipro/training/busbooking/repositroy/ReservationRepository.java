package com.wipro.training.busbooking.repositroy;


import java.sql.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wipro.training.busbooking.model.Bus;
import com.wipro.training.busbooking.model.Reservation;
import com.wipro.training.busbooking.model.User;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    // Find reservations by user
    List<Reservation> findByUser(User user);

    // Find active (non-canceled) reservations by user
    List<Reservation> findByUserAndCanceledFalse(User user);

    Optional<Reservation> findByUserAndBusAndSeatNumber(User user, Bus bus, String seatNumber);

}