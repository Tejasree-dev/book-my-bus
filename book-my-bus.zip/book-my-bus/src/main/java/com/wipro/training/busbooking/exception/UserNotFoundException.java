package com.wipro.training.busbooking.exception;

public class UserNotFoundException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Default constructor
    public UserNotFoundException() {
        super();
    }

    // Constructor that accepts a message
    public UserNotFoundException(String message) {
        super(message);
    }

    // Constructor that accepts a message and a cause
    public UserNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor that accepts a cause
    public UserNotFoundException(Throwable cause) {
        super(cause);
    }
}