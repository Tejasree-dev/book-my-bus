package com.wipro.training.busbooking.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.busbooking.model.Bus;
import com.wipro.training.busbooking.service.BusService;

@RestController
@RequestMapping("/api/buses")
public class BusController {
    @Autowired
    private BusService busService;
    
    @PostMapping("/add")
    public ResponseEntity<Bus> addBus(@RequestBody Bus bus) {
        Bus savedBus = busService.saveBus(bus);
        return new ResponseEntity<>(savedBus, HttpStatus.CREATED);
    }
    
    @GetMapping("/all")
    public ResponseEntity<List<Bus>> getAllBuses() {
        List<Bus> buses = busService.getAllBuses();
        if (buses.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); // No content found
        }
        return new ResponseEntity<>(buses, HttpStatus.OK);
    }


    @GetMapping("/search")
    public ResponseEntity<?> searchBuses(@RequestParam String source, @RequestParam String destination) {
        List<Bus> buses = busService.findBuses(source, destination);
        if (buses.isEmpty()) {
            return new ResponseEntity<>("Buses not available", HttpStatus.NOT_FOUND);  // Custom message for no buses
        }
        return new ResponseEntity<>(buses, HttpStatus.OK);
    }


    @GetMapping("/availability")
    public ResponseEntity<?> checkAvailability(
            @RequestParam String departureLocation,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate) {
        List<Bus> availableBuses = busService.checkBusAvailability(departureLocation, destination, travelDate);
        if (availableBuses.isEmpty()) {
            String message = String.format("No availability of buses for %s to %s on %s", 
                                           departureLocation, destination, travelDate);
            return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);  // Custom message with source, destination, and date
        }
        return new ResponseEntity<>(availableBuses, HttpStatus.OK);
    }
    
    @DeleteMapping("/remove/{id}")
    public ResponseEntity<?> removeBus(@PathVariable Long id) {
        busService.removeBus(id);
        return ResponseEntity.ok("Bus removed successfully");
    }
}
