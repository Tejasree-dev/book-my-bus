package com.wipro.training.busbooking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.training.busbooking.model.Admin;
import com.wipro.training.busbooking.model.AdminLoginRequest;
import com.wipro.training.busbooking.model.Bus;
import com.wipro.training.busbooking.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;
    
    @PostMapping("/add")
    public ResponseEntity<String> addAdmin(@RequestBody Admin admin) {
        try {
            Admin addedAdmin = adminService.addAdmin(admin);
            return ResponseEntity.ok("Admin added successfully: " + addedAdmin.getEmail());
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody AdminLoginRequest loginRequest) {
        try {
            Admin admin = adminService.loginAdmin(loginRequest);
            return ResponseEntity.ok("Admin login successful: " + admin.getEmail());
        } catch (RuntimeException e) {
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @PutMapping("/bus/update")
    public ResponseEntity<Bus> updateBus(@RequestBody Bus bus) {
        Bus updatedBus = adminService.updateBusDetails(bus);
        return ResponseEntity.ok(updatedBus);
    }

    @PutMapping("/route/update")
    public ResponseEntity<String> updateRoute(@RequestParam Long busId, @RequestParam String newSource, @RequestParam String newDestination) {
        adminService.updateRoute(busId, newSource, newDestination);
        return ResponseEntity.ok("Route updated successfully");
    }
}
