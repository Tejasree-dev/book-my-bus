package com.wipro.training.busbooking.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.training.busbooking.model.Admin;
import com.wipro.training.busbooking.model.AdminLoginRequest;
import com.wipro.training.busbooking.model.Bus;
import com.wipro.training.busbooking.repositroy.AdminRepository;
import com.wipro.training.busbooking.repositroy.BusRepository;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private BusRepository busRepository;

    // Method to handle admin login
    public Admin loginAdmin(AdminLoginRequest loginRequest) {
        Admin admin = adminRepository.findByEmailAndPassword(loginRequest.getEmail(), loginRequest.getPassword());
        if (admin != null) {
            return admin;
        }
        throw new RuntimeException("Invalid email or password");
    }

 // Method to check if an admin exists by ID
    public boolean adminExistsById(Long id) {
        return adminRepository.existsById(id);
    }

    // Method to check if an admin exists by email
    public boolean adminExistsByEmail(String email) {
        return adminRepository.existsByEmail(email);
    }

    // Method to handle adding a new admin
    public Admin addAdmin(Admin admin) {
        if (adminExistsById(admin.getId())) {
            throw new RuntimeException("Admin ID already exists");
        }
        if (adminExistsByEmail(admin.getEmail())) {
            throw new RuntimeException("Admin email already exists");
        }
        return adminRepository.save(admin);
    }
    
    public Bus updateBusDetails(Bus bus) {
        return busRepository.save(bus);
    }

    public void updateRoute(Long busId, String newSource, String newDestination) {
        Bus bus = busRepository.findById(busId)
                .orElseThrow(() -> new RuntimeException("Bus not found"));
        bus.setSource(newSource);
        bus.setDestination(newDestination);
        busRepository.save(bus);
    }

    public Admin saveAdmin(Admin admin) {
        return adminRepository.save(admin);
    }
}
