package com.wipro.training.busbooking.exception;

public class ReservationException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	// Default constructor
    public ReservationException() {
        super();
    }

    // Constructor that accepts a message
    public ReservationException(String message) {
        super(message);
    }

    // Constructor that accepts a message and a cause
    public ReservationException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor that accepts a cause
    public ReservationException(Throwable cause) {
        super(cause);
    }
}